package vista.paneles;

import vista.componentes.Estilo;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.BorderFactory;

public class Inicio extends javax.swing.JPanel {

    public Inicio() {
        initComponents();
        Estilo.aplicarImagenResponsive(lblImagen, "/recursos/Inicio.png");
        Estilo.aplicarTitulo(lblBienvenido);
        Estilo.aplicarSubtitulo(lblSeleccione);
        Estilo.aplicarInfo(lblInfo);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        filler1 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));
        lblImagen = new javax.swing.JLabel();
        filler2 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 25), new java.awt.Dimension(0, 0));
        lblBienvenido = new javax.swing.JLabel();
        lblSeleccione = new javax.swing.JLabel();
        filler4 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 20), new java.awt.Dimension(0, 0));
        lblInfo = new javax.swing.JLabel();
        filler5 = new javax.swing.Box.Filler(new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 0), new java.awt.Dimension(0, 32767));

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(new javax.swing.border.LineBorder(new java.awt.Color(220, 220, 220), 1, true));
        setPreferredSize(new java.awt.Dimension(600, 400));
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
        add(filler1);

        lblImagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/Inicio.png"))); // NOI18N
        lblImagen.setAlignmentX(0.5F);
        lblImagen.setInheritsPopupMenu(false);
        lblImagen.setPreferredSize(new java.awt.Dimension(300, 300));
        add(lblImagen);
        add(filler2);

        lblBienvenido.setFont(new java.awt.Font("Segoe UI", 0, 20)); // NOI18N
        lblBienvenido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBienvenido.setText("Bienvenido al Sistema D'Hondt");
        lblBienvenido.setAlignmentX(0.5F);
        lblBienvenido.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblBienvenido.setInheritsPopupMenu(false);
        add(lblBienvenido);

        lblSeleccione.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblSeleccione.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblSeleccione.setText("Seleccione una opción del menú para comenzar");
        lblSeleccione.setAlignmentX(0.5F);
        lblSeleccione.setInheritsPopupMenu(false);
        add(lblSeleccione);
        add(filler4);

        lblInfo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblInfo.setForeground(new java.awt.Color(123, 149, 189));
        lblInfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/recursos/info.png"))); // NOI18N
        lblInfo.setText("<html>Este sistema permite gestionar partidos políticos, votos y calcular<br>la distribución de cargos utilizando el método D'Hondt<html>");
        lblInfo.setAlignmentX(0.5F);
        lblInfo.setInheritsPopupMenu(false);
        add(lblInfo);
        add(filler5);
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.Box.Filler filler1;
    private javax.swing.Box.Filler filler2;
    private javax.swing.Box.Filler filler4;
    private javax.swing.Box.Filler filler5;
    private javax.swing.JLabel lblBienvenido;
    private javax.swing.JLabel lblImagen;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblSeleccione;
    // End of variables declaration//GEN-END:variables
}
